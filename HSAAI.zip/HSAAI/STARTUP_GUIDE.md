# دليل تشغيل HSAAI — خطوة بخطوة

---

## المتطلبات الأساسية

| الأداة | الإصدار | رابط التحميل |
|--------|---------|-------------|
| Python | 3.11+ | https://python.org |
| Docker Desktop | أحدث إصدار | https://docker.com/get-started |
| Git | أي إصدار | https://git-scm.com |

---

## الطريقة الأولى: Docker (الأسهل والأسرع ✅)

### الخطوة 1 — تجهيز المشروع

```bash
# فك ضغط الملف المُرسَل
unzip HSAAI_ENTERPRISE_READY.zip
cd HSAAI
```

### الخطوة 2 — إعداد ملف البيئة

```bash
# انسخ ملف الإعدادات
cp .env .env.backup

# افتح .env وعدّل هذه القيم الإلزامية:
```

افتح ملف `.env` وغيّر:

```env
# 1. أنشئ SECRET_KEY قوي (شغّل هذا الأمر في Terminal):
#    openssl rand -hex 32
SECRET_KEY=ضع_هنا_الناتج_من_الأمر_السابق

# 2. مفتاح OpenAI (احصل عليه من: https://platform.openai.com/api-keys)
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxx

# 3. مفتاح Anthropic (اختياري - من: https://console.anthropic.com)
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
```

### الخطوة 3 — تشغيل Docker

```bash
# بناء وتشغيل جميع الخدمات
docker compose up -d

# مشاهدة اللوجز في الوقت الفعلي
docker compose logs -f backend
```

### الخطوة 4 — التحقق من التشغيل

```bash
# فحص حالة جميع الـ containers
docker compose ps
```

يجب أن تظهر جميع الخدمات بحالة **Up (healthy)**:

```
NAME              STATUS
hsaai_backend     Up (healthy)
hsaai_postgres    Up (healthy)
hsaai_redis       Up (healthy)
hsaai_qdrant      Up
hsaai_celery      Up
hsaai_prometheus  Up
```

### الخطوة 5 — اختبار الـ API

```bash
# 1. اختبار الـ Health Check
curl http://localhost:8000/health

# المتوقع:
# {"status":"ok","version":"1.0.0","env":"development"}

# 2. تسجيل مستخدم جديد
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@hsaai.ai",
    "full_name": "HSAAI Admin",
    "password": "Admin@123456",
    "role": "admin"
  }'

# 3. تسجيل الدخول والحصول على Token
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@hsaai.ai",
    "password": "Admin@123456"
  }'

# احفظ الـ access_token من الرد

# 4. اختبار المستخدم الحالي
curl http://localhost:8000/api/v1/auth/me \
  -H "Authorization: Bearer ACCESS_TOKEN_HERE"
```

---

## الطريقة الثانية: محلي بدون Docker

### الخطوة 1 — تثبيت قواعد البيانات

**PostgreSQL:**
- Windows: https://www.postgresql.org/download/windows/
- Mac: `brew install postgresql@16 && brew services start postgresql@16`
- Ubuntu: `sudo apt install postgresql postgresql-contrib`

**Redis:**
- Windows: https://github.com/tporadowski/redis/releases
- Mac: `brew install redis && brew services start redis`
- Ubuntu: `sudo apt install redis-server`

**Qdrant:**
```bash
docker run -d -p 6333:6333 qdrant/qdrant:v1.12.1
```

### الخطوة 2 — إنشاء قاعدة البيانات

```bash
# الدخول إلى PostgreSQL
psql -U postgres

# تنفيذ هذه الأوامر:
CREATE USER hsaai_user WITH PASSWORD 'hsaai_pass';
CREATE DATABASE hsaai_db OWNER hsaai_user;
GRANT ALL PRIVILEGES ON DATABASE hsaai_db TO hsaai_user;
\q
```

### الخطوة 3 — إعداد Python

```bash
cd HSAAI

# إنشاء بيئة افتراضية
python -m venv venv

# تفعيلها
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# تثبيت المكتبات
pip install -r requirements.txt
```

### الخطوة 4 — تعديل ملف .env للتشغيل المحلي

```env
DATABASE_URL=postgresql+asyncpg://hsaai_user:hsaai_pass@localhost:5432/hsaai_db
REDIS_URL=redis://localhost:6379/0
QDRANT_URL=http://localhost:6333
SECRET_KEY=your-generated-key-here
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxx
```

### الخطوة 5 — تشغيل الـ Backend

```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## الواجهات المتاحة بعد التشغيل

| الواجهة | الرابط | الوصف |
|---------|--------|-------|
| Swagger API Docs | http://localhost:8000/docs | واجهة تفاعلية لاختبار كل الـ endpoints |
| ReDoc | http://localhost:8000/redoc | توثيق الـ API بشكل منظم |
| Health Check | http://localhost:8000/health | حالة التطبيق |
| Metrics | http://localhost:8000/metrics | بيانات Prometheus |
| Prometheus | http://localhost:9090 | لوحة المراقبة |

---

## اختبار الـ RAG Engine

```bash
# 1. استوعب مستنداً
curl -X POST http://localhost:8000/api/v1/rag/ingest \
  -H "Authorization: Bearer ACCESS_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "HSAAI هو نظام ذكاء اصطناعي مؤسسي متكامل يدعم RAG والـ Multi-Agent AI.",
    "metadata": {"source": "manual", "category": "intro"}
  }'

# 2. اسأل سؤالاً
curl -X POST http://localhost:8000/api/v1/rag/query \
  -H "Authorization: Bearer ACCESS_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "ما هو HSAAI؟",
    "top_k": 3
  }'
```

---

## تشغيل الاختبارات

```bash
# داخل بيئة Docker
docker compose exec backend pytest tests/ -v

# محلياً
pytest tests/ -v --cov=backend --cov-report=term-missing
```

---

## إيقاف المشروع

```bash
# إيقاف مؤقت (يحتفظ بالبيانات)
docker compose stop

# إيقاف كامل مع حذف الـ containers (يحتفظ بالبيانات في volumes)
docker compose down

# إيقاف كامل مع حذف كل شيء بما فيه البيانات
docker compose down -v
```

---

## حل المشاكل الشائعة

### المشكلة: backend لا يبدأ
```bash
docker compose logs backend
# ابحث عن سطر يبدأ بـ ERROR
```

### المشكلة: خطأ في قاعدة البيانات
```bash
# تأكد أن postgres يعمل
docker compose ps postgres
# يجب أن يكون (healthy)
```

### المشكلة: خطأ SECRET_KEY
```bash
# أنشئ مفتاحاً قوياً
openssl rand -hex 32
# ثم ضعه في .env
```

### المشكلة: خطأ OpenAI API
```
Error: Incorrect API key provided
```
تأكد أن `OPENAI_API_KEY` في `.env` صحيح ولديه رصيد.

---

## ملاحظة مهمة على الأمان

```bash
# أضف هذه الملفات إلى .gitignore قبل رفع المشروع
echo ".env" >> .gitignore
echo "*.pyc" >> .gitignore
echo "__pycache__/" >> .gitignore
echo "venv/" >> .gitignore
```

لا ترفع ملف `.env` أبداً إلى GitHub — فيه مفاتيح API السرية.
