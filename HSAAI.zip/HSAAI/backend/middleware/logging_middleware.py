import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from backend.core.logging import logger
from backend.monitoring.metrics import HTTP_REQUEST_DURATION, HTTP_REQUESTS_TOTAL


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = str(uuid.uuid4())
        start = time.perf_counter()

        response = await call_next(request)

        elapsed = time.perf_counter() - start
        endpoint = request.url.path

        HTTP_REQUESTS_TOTAL.labels(
            method=request.method,
            endpoint=endpoint,
            status_code=response.status_code,
        ).inc()

        HTTP_REQUEST_DURATION.labels(
            method=request.method,
            endpoint=endpoint,
        ).observe(elapsed)

        logger.info(
            "http_request",
            request_id=request_id,
            method=request.method,
            path=endpoint,
            status=response.status_code,
            elapsed_s=round(elapsed, 4),
        )

        response.headers["X-Request-ID"] = request_id
        return response
