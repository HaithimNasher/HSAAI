"""
HSAAI — Enterprise AI Operating System
Main FastAPI application entry point.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from backend.core.config import settings
from backend.core.logging import logger, setup_logging
from backend.database.session import init_db
from backend.middleware.logging_middleware import RequestLoggingMiddleware
from backend.routers import auth, rag, ai, agents, health, metrics

# ── Rate Limiter ──────────────────────────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    logger.info("hsaai_starting", version=settings.version, env=settings.environment)
    await init_db()
    logger.info("hsaai_ready")
    yield
    logger.info("hsaai_shutdown")


# ── Application ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="HSAAI — Enterprise AI Operating System",
    description=(
        "A production-grade, multi-module AI platform featuring RAG, "
        "Multi-Agent AI, LLM Orchestration, and enterprise security."
    ),
    version=settings.version,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── Middleware ────────────────────────────────────────────────────────────────
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RequestLoggingMiddleware)

# ── Routers ───────────────────────────────────────────────────────────────────
API_PREFIX = "/api/v1"

app.include_router(health.router)
app.include_router(metrics.router)
app.include_router(auth.router, prefix=API_PREFIX)
app.include_router(rag.router, prefix=API_PREFIX)
app.include_router(ai.router, prefix=API_PREFIX)
app.include_router(agents.router, prefix=API_PREFIX)
