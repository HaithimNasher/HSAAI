from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from typing import Any

from backend.auth_service.dependencies import get_current_user
from backend.models.user import User
from backend.rag_engine.engine import get_rag_engine

router = APIRouter(prefix="/rag", tags=["RAG Engine"])


class QueryRequest(BaseModel):
    question: str
    top_k: int = 5


class IngestRequest(BaseModel):
    text: str
    metadata: dict[str, Any] = {}


@router.post("/ingest")
async def ingest_text(
    body: IngestRequest,
    current_user: User = Depends(get_current_user),
):
    engine = get_rag_engine()
    ids = await engine.ingest_document(body.text, {**body.metadata, "user_id": str(current_user.id)})
    return {"ingested_chunks": len(ids), "point_ids": ids}


@router.post("/ingest/file")
async def ingest_file(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    if file.content_type not in ("text/plain", "application/pdf"):
        raise HTTPException(status_code=400, detail="Only .txt and .pdf files supported")
    content = await file.read()
    text = content.decode("utf-8", errors="ignore")
    engine = get_rag_engine()
    ids = await engine.ingest_document(text, {"filename": file.filename, "user_id": str(current_user.id)})
    return {"filename": file.filename, "ingested_chunks": len(ids)}


@router.post("/query")
async def query_rag(
    body: QueryRequest,
    current_user: User = Depends(get_current_user),
):
    engine = get_rag_engine()
    result = await engine.query(body.question, body.top_k)
    return result
