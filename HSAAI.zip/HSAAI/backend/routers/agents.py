from fastapi import APIRouter, Depends, BackgroundTasks
from pydantic import BaseModel

from backend.auth_service.dependencies import require_engineer
from backend.models.user import User
from backend.multi_agents.agents import run_research_crew

router = APIRouter(prefix="/agents", tags=["Multi-Agent AI"])


class ResearchRequest(BaseModel):
    topic: str


@router.post("/research")
async def research(
    body: ResearchRequest,
    current_user: User = Depends(require_engineer),
):
    result = await run_research_crew(body.topic)
    return result
