from fastapi import APIRouter
from fastapi.responses import PlainTextResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

from backend.monitoring.metrics import REGISTRY

router = APIRouter(tags=["Monitoring"])


@router.get("/metrics", response_class=PlainTextResponse, include_in_schema=False)
async def metrics():
    return PlainTextResponse(
        content=generate_latest(REGISTRY),
        media_type=CONTENT_TYPE_LATEST,
    )
