from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Any

from backend.auth_service.dependencies import get_current_user
from backend.models.user import User
from backend.ai_orchestrator.orchestrator import OrchestratorRequest, get_orchestrator

router = APIRouter(prefix="/ai", tags=["AI Orchestrator"])


class CompletionRequest(BaseModel):
    prompt: str
    system_prompt: str = "You are a helpful enterprise AI assistant."
    model: str = "gpt-4o"
    temperature: float = 0.3
    max_tokens: int = 2048


@router.post("/completion")
async def complete(
    body: CompletionRequest,
    current_user: User = Depends(get_current_user),
) -> dict[str, Any]:
    orchestrator = get_orchestrator()
    req = OrchestratorRequest(
        prompt=body.prompt,
        system_prompt=body.system_prompt,
        model=body.model,
        temperature=body.temperature,
        max_tokens=body.max_tokens,
        metadata={"user_id": str(current_user.id)},
    )
    return await orchestrator.run(req)
