from fastapi import APIRouter
from fastapi.responses import JSONResponse

from backend.core.config import settings
from backend.services.cache import get_redis

router = APIRouter(tags=["Health"])


@router.get("/health", summary="Liveness probe")
async def health():
    return {"status": "ok", "version": settings.version, "env": settings.environment}


@router.get("/health/ready", summary="Readiness probe")
async def readiness():
    checks: dict[str, str] = {}
    overall = "ok"

    # Redis
    try:
        r = await get_redis()
        await r.ping()
        checks["redis"] = "ok"
    except Exception as exc:
        checks["redis"] = f"error: {exc}"
        overall = "degraded"

    status_code = 200 if overall == "ok" else 503
    return JSONResponse(
        content={"status": overall, "checks": checks},
        status_code=status_code,
    )
