"""
Redis cache service with async support.
"""
import json
from typing import Any

import redis.asyncio as aioredis

from backend.core.config import settings
from backend.core.logging import logger

_redis: aioredis.Redis | None = None


async def get_redis() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis


async def cache_set(key: str, value: Any, ttl: int = settings.redis_cache_ttl) -> None:
    r = await get_redis()
    await r.setex(key, ttl, json.dumps(value, default=str))
    logger.debug("cache_set", key=key, ttl=ttl)


async def cache_get(key: str) -> Any | None:
    r = await get_redis()
    raw = await r.get(key)
    if raw is None:
        return None
    logger.debug("cache_hit", key=key)
    return json.loads(raw)


async def cache_delete(key: str) -> None:
    r = await get_redis()
    await r.delete(key)


async def cache_clear_prefix(prefix: str) -> int:
    r = await get_redis()
    keys = await r.keys(f"{prefix}*")
    if keys:
        return await r.delete(*keys)
    return 0
