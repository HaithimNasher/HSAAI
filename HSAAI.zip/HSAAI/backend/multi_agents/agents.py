"""
Multi-Agent System built on CrewAI.
Includes: Researcher, Analyst, Writer, and QA agents.
"""
from __future__ import annotations

from crewai import Agent, Crew, Process, Task
from langchain_openai import ChatOpenAI

from backend.core.config import settings
from backend.core.logging import logger


def _llm() -> ChatOpenAI:
    return ChatOpenAI(
        model=settings.default_llm_model,
        openai_api_key=settings.openai_api_key,
        temperature=0.3,
    )


# ── Agents ────────────────────────────────────────────────────────────────────

def build_researcher() -> Agent:
    return Agent(
        role="Senior Research Analyst",
        goal="Research and gather comprehensive information on the given topic.",
        backstory="You are an expert researcher with deep analytical skills.",
        llm=_llm(),
        verbose=False,
        allow_delegation=False,
    )


def build_analyst() -> Agent:
    return Agent(
        role="Business Analyst",
        goal="Analyze research findings and extract key insights.",
        backstory="You specialize in turning raw data into actionable business intelligence.",
        llm=_llm(),
        verbose=False,
        allow_delegation=False,
    )


def build_writer() -> Agent:
    return Agent(
        role="Technical Writer",
        goal="Produce clear, concise, professional reports.",
        backstory="You excel at communicating complex ideas to diverse audiences.",
        llm=_llm(),
        verbose=False,
        allow_delegation=False,
    )


# ── Crew Factory ──────────────────────────────────────────────────────────────

def create_research_crew(topic: str) -> Crew:
    researcher = build_researcher()
    analyst = build_analyst()
    writer = build_writer()

    tasks = [
        Task(
            description=f"Research the following topic thoroughly: {topic}",
            expected_output="A comprehensive research summary with key facts and data.",
            agent=researcher,
        ),
        Task(
            description="Analyze the research and identify the top 5 actionable insights.",
            expected_output="A bullet-point list of insights with supporting rationale.",
            agent=analyst,
        ),
        Task(
            description="Write a professional executive report based on the analysis.",
            expected_output="A well-structured report with introduction, findings, and recommendations.",
            agent=writer,
        ),
    ]

    return Crew(
        agents=[researcher, analyst, writer],
        tasks=tasks,
        process=Process.sequential,
        verbose=False,
    )


async def run_research_crew(topic: str) -> dict:
    logger.info("crew_start", topic=topic)
    crew = create_research_crew(topic)
    result = crew.kickoff()
    logger.info("crew_finished", topic=topic)
    return {"topic": topic, "report": str(result)}
