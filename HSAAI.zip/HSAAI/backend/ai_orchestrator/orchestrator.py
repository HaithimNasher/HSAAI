"""
AI Orchestrator – routes requests to the appropriate LLM provider,
handles retries, fallback, and token tracking.
"""
from __future__ import annotations

import time
from enum import Enum
from typing import Any

from langchain_openai import ChatOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

from backend.core.config import settings
from backend.core.logging import logger


class LLMProvider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


class OrchestratorRequest:
    def __init__(
        self,
        prompt: str,
        system_prompt: str = "You are a helpful enterprise AI assistant.",
        provider: LLMProvider = LLMProvider.OPENAI,
        model: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 2048,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.prompt = prompt
        self.system_prompt = system_prompt
        self.provider = provider
        self.model = model or settings.default_llm_model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.metadata = metadata or {}


class AIOrchestrator:
    def __init__(self) -> None:
        self._clients: dict[str, Any] = {}

    def _get_openai_client(self, model: str, temperature: float) -> ChatOpenAI:
        key = f"openai:{model}:{temperature}"
        if key not in self._clients:
            self._clients[key] = ChatOpenAI(
                model=model,
                openai_api_key=settings.openai_api_key,
                temperature=temperature,
            )
        return self._clients[key]

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def _call_openai(self, req: OrchestratorRequest) -> str:
        client = self._get_openai_client(req.model, req.temperature)
        messages = [
            {"role": "system", "content": req.system_prompt},
            {"role": "user", "content": req.prompt},
        ]
        response = await client.ainvoke(messages)
        return response.content

    async def run(self, req: OrchestratorRequest) -> dict[str, Any]:
        start = time.perf_counter()
        try:
            if req.provider == LLMProvider.OPENAI:
                content = await self._call_openai(req)
            else:
                raise NotImplementedError(f"Provider {req.provider} not yet implemented")

            elapsed = round(time.perf_counter() - start, 3)
            logger.info(
                "orchestrator_run_success",
                provider=req.provider,
                model=req.model,
                elapsed_s=elapsed,
            )
            return {
                "content": content,
                "provider": req.provider,
                "model": req.model,
                "elapsed_s": elapsed,
            }

        except Exception as exc:
            logger.error("orchestrator_run_failed", error=str(exc))
            raise


_orchestrator: AIOrchestrator | None = None


def get_orchestrator() -> AIOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = AIOrchestrator()
    return _orchestrator
