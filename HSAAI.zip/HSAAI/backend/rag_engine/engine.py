"""
RAG (Retrieval-Augmented Generation) Engine
Supports: document ingestion, chunking, embedding, retrieval, generation
"""
from __future__ import annotations

import hashlib
import uuid
from typing import Any

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

from backend.core.config import settings
from backend.core.logging import logger


class RAGEngine:
    def __init__(self) -> None:
        self.embeddings = OpenAIEmbeddings(
            model=settings.default_embedding_model,
            openai_api_key=settings.openai_api_key,
        )
        self.llm = ChatOpenAI(
            model=settings.default_llm_model,
            openai_api_key=settings.openai_api_key,
            temperature=0.2,
        )
        self.qdrant = AsyncQdrantClient(url=settings.qdrant_url)
        self.collection = settings.qdrant_collection
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000, chunk_overlap=200
        )

    # ── Setup ──────────────────────────────────────────────────────────────────

    async def ensure_collection(self) -> None:
        collections = await self.qdrant.get_collections()
        names = [c.name for c in collections.collections]
        if self.collection not in names:
            await self.qdrant.create_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(
                    size=settings.qdrant_vector_size,
                    distance=Distance.COSINE,
                ),
            )
            logger.info("qdrant_collection_created", collection=self.collection)

    # ── Ingestion ──────────────────────────────────────────────────────────────

    async def ingest_document(
        self, text: str, metadata: dict[str, Any] | None = None
    ) -> list[str]:
        """Chunk, embed, and store a document. Returns list of point IDs."""
        await self.ensure_collection()
        chunks = self.splitter.split_text(text)
        vectors = await self.embeddings.aembed_documents(chunks)

        points: list[PointStruct] = []
        ids: list[str] = []
        for chunk, vector in zip(chunks, vectors):
            point_id = str(uuid.uuid4())
            doc_hash = hashlib.md5(chunk.encode()).hexdigest()
            points.append(
                PointStruct(
                    id=point_id,
                    vector=vector,
                    payload={
                        "text": chunk,
                        "hash": doc_hash,
                        **(metadata or {}),
                    },
                )
            )
            ids.append(point_id)

        await self.qdrant.upsert(collection_name=self.collection, points=points)
        logger.info("document_ingested", chunks=len(chunks), collection=self.collection)
        return ids

    # ── Retrieval ──────────────────────────────────────────────────────────────

    async def retrieve(self, query: str, top_k: int = 5) -> list[dict[str, Any]]:
        """Return top-k relevant chunks for a query."""
        query_vector = await self.embeddings.aembed_query(query)
        results = await self.qdrant.search(
            collection_name=self.collection,
            query_vector=query_vector,
            limit=top_k,
            with_payload=True,
        )
        return [
            {"score": r.score, "text": r.payload.get("text", ""), "metadata": r.payload}
            for r in results
        ]

    # ── Generation ─────────────────────────────────────────────────────────────

    async def query(self, question: str, top_k: int = 5) -> dict[str, Any]:
        """Full RAG: retrieve context then generate answer."""
        chunks = await self.retrieve(question, top_k)
        context = "\n\n".join(c["text"] for c in chunks)

        prompt = (
            "You are a helpful enterprise AI assistant. "
            "Answer the question using ONLY the context below.\n\n"
            f"Context:\n{context}\n\n"
            f"Question: {question}\n\nAnswer:"
        )

        response = await self.llm.ainvoke(prompt)
        return {
            "answer": response.content,
            "sources": chunks,
            "model": settings.default_llm_model,
        }


# Singleton
_rag_engine: RAGEngine | None = None


def get_rag_engine() -> RAGEngine:
    global _rag_engine
    if _rag_engine is None:
        _rag_engine = RAGEngine()
    return _rag_engine
