"""
Prometheus metrics for the HSAAI platform.
"""
from prometheus_client import Counter, Gauge, Histogram, CollectorRegistry

REGISTRY = CollectorRegistry()

# HTTP
HTTP_REQUESTS_TOTAL = Counter(
    "hsaai_http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status_code"],
    registry=REGISTRY,
)

HTTP_REQUEST_DURATION = Histogram(
    "hsaai_http_request_duration_seconds",
    "HTTP request latency",
    ["method", "endpoint"],
    buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.5, 5.0, 10.0],
    registry=REGISTRY,
)

# LLM
LLM_REQUESTS_TOTAL = Counter(
    "hsaai_llm_requests_total",
    "Total LLM API calls",
    ["provider", "model"],
    registry=REGISTRY,
)

LLM_LATENCY = Histogram(
    "hsaai_llm_latency_seconds",
    "LLM call latency",
    ["provider", "model"],
    buckets=[0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0],
    registry=REGISTRY,
)

LLM_ERRORS_TOTAL = Counter(
    "hsaai_llm_errors_total",
    "Total LLM API errors",
    ["provider", "error_type"],
    registry=REGISTRY,
)

# RAG
RAG_QUERIES_TOTAL = Counter(
    "hsaai_rag_queries_total",
    "Total RAG queries",
    registry=REGISTRY,
)

RAG_INGESTED_CHUNKS = Counter(
    "hsaai_rag_ingested_chunks_total",
    "Total document chunks ingested",
    registry=REGISTRY,
)

# System
ACTIVE_USERS = Gauge(
    "hsaai_active_users",
    "Currently authenticated active users",
    registry=REGISTRY,
)

AGENT_TASKS_TOTAL = Counter(
    "hsaai_agent_tasks_total",
    "Total multi-agent tasks executed",
    ["status"],
    registry=REGISTRY,
)
