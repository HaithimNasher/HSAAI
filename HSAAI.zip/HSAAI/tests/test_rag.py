"""
RAG engine unit tests (mocked Qdrant and OpenAI).
"""
import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from backend.rag_engine.engine import RAGEngine


@pytest.fixture
def engine():
    with patch("backend.rag_engine.engine.OpenAIEmbeddings"), \
         patch("backend.rag_engine.engine.ChatOpenAI"), \
         patch("backend.rag_engine.engine.AsyncQdrantClient"):
        e = RAGEngine()
        return e


@pytest.mark.asyncio
async def test_ingest_document(engine):
    engine.embeddings.aembed_documents = AsyncMock(return_value=[[0.1] * 1536])
    engine.qdrant.get_collections = AsyncMock(return_value=MagicMock(collections=[MagicMock(name="hsaai_vectors")]))
    engine.qdrant.upsert = AsyncMock()

    ids = await engine.ingest_document("Hello world test document for HSAAI.")
    assert len(ids) >= 1


@pytest.mark.asyncio
async def test_retrieve(engine):
    engine.embeddings.aembed_query = AsyncMock(return_value=[0.1] * 1536)
    mock_result = MagicMock(score=0.95, payload={"text": "Sample text"})
    engine.qdrant.search = AsyncMock(return_value=[mock_result])

    results = await engine.retrieve("test query", top_k=1)
    assert len(results) == 1
    assert results[0]["score"] == 0.95
    assert results[0]["text"] == "Sample text"
