# HSAAI — Enterprise AI Operating System

![Python](https://img.shields.io/badge/Python-3.11-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.115-green)
![License](https://img.shields.io/badge/license-MIT-blue)

A production-grade, multi-module Enterprise AI Platform built with FastAPI, LangChain, CrewAI, and Qdrant.

---

## Architecture

```
HSAAI/
├── backend/
│   ├── main.py                    # FastAPI app entry point
│   ├── core/
│   │   ├── config.py              # Pydantic settings (env-driven)
│   │   └── logging.py             # Structured JSON logging
│   ├── database/
│   │   └── session.py             # Async SQLAlchemy engine
│   ├── models/
│   │   └── user.py                # ORM models
│   ├── auth_service/
│   │   ├── service.py             # JWT auth, password hashing
│   │   └── dependencies.py        # FastAPI auth dependencies, RBAC
│   ├── ai_orchestrator/
│   │   └── orchestrator.py        # LLM routing, retry, fallback
│   ├── rag_engine/
│   │   └── engine.py              # Ingest → Embed → Retrieve → Generate
│   ├── multi_agents/
│   │   └── agents.py              # CrewAI Researcher/Analyst/Writer
│   ├── monitoring/
│   │   └── metrics.py             # Prometheus counters/histograms
│   ├── middleware/
│   │   └── logging_middleware.py  # Request logging + metrics
│   ├── services/
│   │   └── cache.py               # Redis async cache
│   └── routers/
│       ├── auth.py                # POST /auth/register, /login, GET /me
│       ├── ai.py                  # POST /ai/completion
│       ├── rag.py                 # POST /rag/ingest, /rag/query
│       ├── agents.py              # POST /agents/research
│       ├── health.py              # GET /health, /health/ready
│       └── metrics.py             # GET /metrics (Prometheus)
├── tests/
│   ├── test_auth.py
│   └── test_rag.py
├── scripts/
│   └── prometheus.yml
├── .github/workflows/
│   └── ci.yml                     # CI: test + lint + docker build
├── Dockerfile
├── docker-compose.yml
├── requirements.txt               # Pinned versions
├── alembic.ini
├── pytest.ini
└── .env                           # Environment variables (never commit)
```

---

## Modules

| Module | Description |
|--------|-------------|
| `auth_service` | JWT authentication, bcrypt passwords, RBAC roles |
| `ai_orchestrator` | LLM routing with retry/fallback (OpenAI, Anthropic) |
| `rag_engine` | Full RAG: chunk → embed → store in Qdrant → retrieve → generate |
| `multi_agents` | CrewAI multi-agent pipeline (Researcher, Analyst, Writer) |
| `monitoring` | Prometheus metrics for HTTP, LLM, RAG, agents |
| `middleware` | Structured request logging with request IDs |
| `services/cache` | Async Redis cache layer |
| `database` | Async PostgreSQL via SQLAlchemy 2.0 |

---

## Quick Start

### 1. Clone & configure
```bash
git clone <repo>
cd HSAAI
cp .env .env.local
# Edit .env.local and set your API keys
```

### 2. Run with Docker
```bash
docker compose up -d
```

### 3. Run locally
```bash
pip install -r requirements.txt
uvicorn backend.main:app --reload
```

### 4. Run tests
```bash
pytest tests/ -v --cov=backend
```

---

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/health` | ❌ | Liveness probe |
| GET | `/health/ready` | ❌ | Readiness probe (Redis check) |
| GET | `/metrics` | ❌ | Prometheus metrics |
| POST | `/api/v1/auth/register` | ❌ | Register user |
| POST | `/api/v1/auth/login` | ❌ | Login, get JWT tokens |
| GET | `/api/v1/auth/me` | ✅ | Current user info |
| POST | `/api/v1/ai/completion` | ✅ | LLM completion |
| POST | `/api/v1/rag/ingest` | ✅ | Ingest text into vector store |
| POST | `/api/v1/rag/ingest/file` | ✅ | Ingest uploaded file |
| POST | `/api/v1/rag/query` | ✅ | RAG question answering |
| POST | `/api/v1/agents/research` | ✅ Engineer | Multi-agent research task |

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `SECRET_KEY` | ✅ | JWT signing key (`openssl rand -hex 32`) |
| `DATABASE_URL` | ✅ | PostgreSQL async URL |
| `OPENAI_API_KEY` | ✅ | OpenAI API key |
| `REDIS_URL` | ✅ | Redis connection URL |
| `QDRANT_URL` | ✅ | Qdrant vector store URL |
| `ANTHROPIC_API_KEY` | ⭕ | Anthropic API key (optional) |

---

## Infrastructure

- **PostgreSQL 16** — primary database
- **Redis 7** — caching and task queue
- **Qdrant 1.12** — vector store for RAG
- **Celery** — background task processing
- **Prometheus** — metrics collection

---

## Phases Roadmap

- [x] Phase 1: Core API + Auth + Database
- [x] Phase 2: RAG Engine
- [x] Phase 3: AI Orchestrator
- [x] Phase 4: Multi-Agent AI
- [ ] Phase 5: Voice AI (Whisper + TTS)
- [ ] Phase 6: Workflow Engine (LangGraph)
- [ ] Phase 7: Enterprise Integrations (SAP, Salesforce)
- [ ] Phase 8: AI Operating System (full autonomy)
